// Angular Rails Templates 0.1.3
//
// angular_templates.ignore_prefix: ["templates/"]
// angular_templates.markups: ["erb", "str"]
// angular_templates.htmlcompressor: false

angular.module("templates", []);

