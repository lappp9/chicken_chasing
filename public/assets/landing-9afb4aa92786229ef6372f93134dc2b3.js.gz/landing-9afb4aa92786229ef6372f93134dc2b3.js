(function() {
  $(function() {
    return $('.mail-button').click(function() {
      return $('.submit').click();
    });
  });

}).call(this);
