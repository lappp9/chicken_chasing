(function(){
	
  angular.module('Checkout.Controllers').controller('CheckOutCtrl', [ '$scope',
    function($scope){
      $scope.message = 'Check Out';
    }]);

})();
